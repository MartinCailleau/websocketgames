﻿using UnityEngine;
using System.Collections;

public class TestObject {
    public int test;
    public string test2;
}